//This program will accpet and return a birthday 
import java.io.*;
import java.util.Scanner;
import java.lang.String;
import java.lang.StringBuffer;

public class main{
	public static void main(String arg[]) throws IOException {
		int day, month, year;
		Scanner input = new Scanner(System.in);
		StringBuffer birthday = new StringBuffer();
		
		System.out.println("Enter a day: ");
		day = input.nextInt();
		
		System.out.println("Enter a month: ");
		month = input.nextInt();
		
		System.out.println("Enter a year: ");
		year = input.nextInt();
		
		birthday.append(month);
		birthday.append("/");
		birthday.append(day);
		birthday.append("/");
		birthday.append(year);
		
		System.out.println("Your birthday is: " + birthday);
	}
}